mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.26.12-source.tar.gz'
pymupdf_version = '1.26.7'
pymupdf_version_tuple = (1, 26, 7)
pymupdf_git_sha = ''
pymupdf_git_diff = ''
pymupdf_git_branch = ''
swig_version = '4.3.1'
swig_version_tuple = (4, 3, 1)
